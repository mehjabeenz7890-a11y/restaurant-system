from django.contrib import admin, messages

from . import services
from .models import (
    Category, Ingredient, MenuItem, Order, OrderItem, RecipeItem, Reservation, Table,
)

admin.site.site_header = "Restaurant Management"


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ["name"]


class RecipeInline(admin.TabularInline):
    model = RecipeItem
    extra = 1


@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ["name", "category", "price", "is_active"]
    list_filter = ["category", "is_active"]
    search_fields = ["name"]
    inlines = [RecipeInline]


@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    list_display = ["name", "quantity", "unit", "reorder_level", "low_stock"]
    search_fields = ["name"]

    @admin.display(boolean=True, description="Low stock?")
    def low_stock(self, obj):
        return obj.is_low


@admin.register(Table)
class TableAdmin(admin.ModelAdmin):
    list_display = ["number", "capacity", "location", "is_active"]
    list_filter = ["is_active"]


@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ["customer_name", "table", "party_size", "start_time", "duration_minutes", "status"]
    list_filter = ["status", "table"]
    date_hierarchy = "start_time"
    search_fields = ["customer_name", "customer_phone"]


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    can_delete = False
    readonly_fields = ["menu_item", "quantity", "unit_price"]

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ["id", "table", "customer_name", "status", "total", "created_at"]
    list_filter = ["status", "created_at"]
    date_hierarchy = "created_at"
    # Items/total/status are read-only here so stock stays consistent;
    # use the actions below or the API to change state.
    readonly_fields = ["status", "total", "created_at", "updated_at"]
    inlines = [OrderItemInline]
    actions = ["mark_preparing", "mark_served", "mark_paid", "cancel_and_restock"]

    def has_add_permission(self, request):
        return False  # orders are created through the API / services

    def _bulk(self, request, queryset, new_status):
        done = 0
        for order in queryset:
            try:
                services.change_order_status(order, new_status)
                done += 1
            except Exception as exc:  # show the reason, keep going
                self.message_user(request, f"Order #{order.pk}: {exc}", messages.WARNING)
        self.message_user(request, f"{done} order(s) set to {new_status}.")

    @admin.action(description="Mark as PREPARING")
    def mark_preparing(self, request, queryset):
        self._bulk(request, queryset, Order.Status.PREPARING)

    @admin.action(description="Mark as SERVED")
    def mark_served(self, request, queryset):
        self._bulk(request, queryset, Order.Status.SERVED)

    @admin.action(description="Mark as PAID")
    def mark_paid(self, request, queryset):
        self._bulk(request, queryset, Order.Status.PAID)

    @admin.action(description="Cancel (pending only) and restock ingredients")
    def cancel_and_restock(self, request, queryset):
        self._bulk(request, queryset, Order.Status.CANCELLED)
