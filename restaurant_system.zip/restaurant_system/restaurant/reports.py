from datetime import datetime, time, timedelta
from decimal import Decimal

from django.db.models import Count, DecimalField, F, Sum
from django.utils import timezone

from .models import Ingredient, Order, OrderItem

ZERO = Decimal("0.00")


def daily_sales(day):
    start = timezone.make_aware(datetime.combine(day, time.min))
    end = start + timedelta(days=1)
    orders = Order.objects.filter(created_at__gte=start, created_at__lt=end)
    valid = orders.exclude(status=Order.Status.CANCELLED)

    agg = valid.aggregate(revenue=Sum("total"), count=Count("id"))
    revenue = agg["revenue"] or ZERO
    count = agg["count"]
    paid = valid.filter(status=Order.Status.PAID).aggregate(s=Sum("total"))["s"] or ZERO

    top = (
        OrderItem.objects.filter(order__in=valid)
        .values("menu_item__name")
        .annotate(
            units_sold=Sum("quantity"),
            item_revenue=Sum(
                F("quantity") * F("unit_price"),
                output_field=DecimalField(max_digits=12, decimal_places=2),
            ),
        )
        .order_by("-units_sold")[:5]
    )
    return {
        "date": day.isoformat(),
        "total_orders": count,
        "cancelled_orders": orders.filter(status=Order.Status.CANCELLED).count(),
        "revenue": revenue,
        "paid_revenue": paid,
        "average_order_value": (revenue / count).quantize(Decimal("0.01")) if count else ZERO,
        "top_items": [
            {"item": r["menu_item__name"], "units_sold": r["units_sold"], "revenue": r["item_revenue"]}
            for r in top
        ],
    }


def stock_alerts():
    return Ingredient.objects.filter(quantity__lte=F("reorder_level")).order_by("quantity")
