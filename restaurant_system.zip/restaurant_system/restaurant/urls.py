from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("categories", views.CategoryViewSet)
router.register("menu-items", views.MenuItemViewSet)
router.register("recipe-items", views.RecipeItemViewSet)
router.register("inventory", views.IngredientViewSet)
router.register("tables", views.TableViewSet)
router.register("reservations", views.ReservationViewSet)
router.register("orders", views.OrderViewSet)

urlpatterns = [
    path("menu/", views.MenuView.as_view(), name="menu"),
    path("reports/daily-sales/", views.DailySalesView.as_view(), name="report-daily-sales"),
    path("reports/stock-alerts/", views.StockAlertsView.as_view(), name="report-stock-alerts"),
    path("", include(router.urls)),
]
