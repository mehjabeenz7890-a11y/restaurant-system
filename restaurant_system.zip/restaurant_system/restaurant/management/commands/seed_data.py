from datetime import timedelta
from decimal import Decimal as D

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from restaurant.models import Category, Ingredient, MenuItem, RecipeItem, Table

INGREDIENTS = [  # name, unit, stock, reorder level
    ("Flour", "kg", "25", "5"), ("Mozzarella", "kg", "10", "2"), ("Tomato Sauce", "l", "8", "2"),
    ("Chicken Breast", "kg", "12", "3"), ("Pasta", "kg", "15", "3"), ("Cream", "l", "6", "2"),
    ("Lettuce", "kg", "4", "1"), ("Coffee Beans", "kg", "5", "1"), ("Milk", "l", "20", "5"),
]

MENU = {  # category -> [(name, price, description, {ingredient: qty per serving})]
    "Pizza": [
        ("Margherita Pizza", "299.00", "Classic tomato and mozzarella",
         {"Flour": "0.250", "Mozzarella": "0.150", "Tomato Sauce": "0.100"}),
    ],
    "Mains": [
        ("Chicken Alfredo", "349.00", "Creamy pasta with grilled chicken",
         {"Pasta": "0.200", "Chicken Breast": "0.150", "Cream": "0.100"}),
    ],
    "Starters": [
        ("Garden Salad", "149.00", "Fresh greens", {"Lettuce": "0.120"}),
    ],
    "Drinks": [
        ("Cappuccino", "119.00", "Espresso with steamed milk", {"Coffee Beans": "0.018", "Milk": "0.150"}),
    ],
}


class Command(BaseCommand):
    help = "Load demo menu, inventory, tables and a dev admin user (admin / admin123)."

    @transaction.atomic
    def handle(self, *args, **options):
        ings = {}
        for name, unit, qty, reorder in INGREDIENTS:
            ings[name], _ = Ingredient.objects.get_or_create(
                name=name, defaults={"unit": unit, "quantity": D(qty), "reorder_level": D(reorder)}
            )
        for cat_name, items in MENU.items():
            cat, _ = Category.objects.get_or_create(name=cat_name)
            for name, price, desc, recipe in items:
                item, _ = MenuItem.objects.get_or_create(
                    name=name, defaults={"category": cat, "price": D(price), "description": desc}
                )
                for ing_name, q in recipe.items():
                    RecipeItem.objects.get_or_create(menu_item=item, ingredient=ings[ing_name], defaults={"quantity": D(q)})
        for number, cap, loc in [(1, 2, "Window"), (2, 2, "Window"), (3, 4, "Main hall"),
                                 (4, 4, "Main hall"), (5, 6, "Patio"), (6, 8, "Private room")]:
            Table.objects.get_or_create(number=number, defaults={"capacity": cap, "location": loc})

        User = get_user_model()
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@example.com", "admin123")
            self.stdout.write("Created dev superuser admin / admin123 (change it!)")
        self.stdout.write(self.style.SUCCESS("Demo data loaded."))
