from rest_framework import mixins, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import SAFE_METHODS, AllowAny, BasePermission, IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Prefetch
from django.utils import timezone
from django.utils.dateparse import parse_date

from . import reports, services
from .models import Category, Ingredient, MenuItem, Order, RecipeItem, Reservation, Table
from .serializers import (
    AvailabilityQuerySerializer, CategorySerializer, IngredientSerializer, MenuCategorySerializer,
    MenuItemSerializer, OrderCreateSerializer, OrderSerializer, OrderStatusSerializer,
    RecipeItemSerializer, RestockSerializer, ReservationSerializer, TableSerializer,
)


class IsStaffOrReadOnly(BasePermission):
    """Anyone can read; only staff can write."""

    def has_permission(self, request, view):
        return request.method in SAFE_METHODS or bool(request.user and request.user.is_staff)


# ------------------------------------------------------------------------ menu
class MenuView(APIView):
    """GET /api/menu/ — public menu grouped by category (active items only)."""

    permission_classes = [AllowAny]

    def get(self, request):
        items = MenuItem.objects.filter(is_active=True).prefetch_related("recipe__ingredient")
        categories = Category.objects.prefetch_related(Prefetch("items", queryset=items))
        categories = [c for c in categories if c.items.all()]
        return Response(MenuCategorySerializer(categories, many=True).data)


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsStaffOrReadOnly]


class MenuItemViewSet(viewsets.ModelViewSet):
    queryset = MenuItem.objects.select_related("category").prefetch_related("recipe__ingredient")
    serializer_class = MenuItemSerializer
    permission_classes = [IsStaffOrReadOnly]


class RecipeItemViewSet(viewsets.ModelViewSet):
    queryset = RecipeItem.objects.select_related("ingredient", "menu_item")
    serializer_class = RecipeItemSerializer  # staff only (default permission)


# ------------------------------------------------------------------- inventory
class IngredientViewSet(viewsets.ModelViewSet):
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer  # staff only

    @action(detail=True, methods=["post"])
    def restock(self, request, pk=None):
        """POST /api/inventory/{id}/restock/  {"quantity": 5}"""
        s = RestockSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        ing = services.restock(self.get_object(), s.validated_data["quantity"])
        return Response(IngredientSerializer(ing).data)

    @action(detail=False, methods=["get"], url_path="low-stock")
    def low_stock(self, request):
        return Response(IngredientSerializer(reports.stock_alerts(), many=True).data)


# ---------------------------------------------------------------------- tables
class TableViewSet(viewsets.ModelViewSet):
    queryset = Table.objects.all()
    serializer_class = TableSerializer

    def get_permissions(self):
        return [AllowAny()] if self.action == "available" else [IsAdminUser()]

    @action(detail=False, methods=["get"])
    def available(self, request):
        """GET /api/tables/available/?start=2026-10-20T19:00:00Z&party_size=4&duration_minutes=90"""
        q = AvailabilityQuerySerializer(data=request.query_params)
        q.is_valid(raise_exception=True)
        d = q.validated_data
        tables = services.available_tables(d["start"], d["duration_minutes"], d["party_size"])
        return Response(TableSerializer(tables, many=True).data)


class ReservationViewSet(
    mixins.CreateModelMixin, mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = Reservation.objects.select_related("table")
    serializer_class = ReservationSerializer

    def get_permissions(self):
        return [AllowAny()] if self.action == "create" else [IsAdminUser()]

    def get_queryset(self):
        qs = super().get_queryset()
        if day := self.request.query_params.get("date"):
            parsed = parse_date(day)
            if not parsed:
                raise ValidationError({"date": "Use YYYY-MM-DD."})
            qs = qs.filter(start_time__date=parsed)
        return qs

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        res = services.cancel_reservation(self.get_object())
        return Response(self.get_serializer(res).data)


# ---------------------------------------------------------------------- orders
class OrderViewSet(
    mixins.CreateModelMixin, mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = Order.objects.select_related("table").prefetch_related("items__menu_item")

    def get_permissions(self):
        return [AllowAny()] if self.action == "create" else [IsAdminUser()]

    def get_serializer_class(self):
        return OrderCreateSerializer if self.action == "create" else OrderSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        if st := self.request.query_params.get("status"):
            qs = qs.filter(status=st.upper())
        return qs

    def create(self, request, *args, **kwargs):
        s = self.get_serializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = s.save()
        return Response(OrderSerializer(order).data, status=201)

    @action(detail=True, methods=["post"])
    def status(self, request, pk=None):
        """POST /api/orders/{id}/status/  {"status": "PREPARING"}"""
        s = OrderStatusSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        order = services.change_order_status(self.get_object(), s.validated_data["status"])
        return Response(OrderSerializer(order).data)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        order = services.change_order_status(self.get_object(), Order.Status.CANCELLED)
        return Response(OrderSerializer(order).data)


# --------------------------------------------------------------------- reports
class DailySalesView(APIView):
    """GET /api/reports/daily-sales/?date=YYYY-MM-DD (defaults to today)."""

    def get(self, request):
        raw = request.query_params.get("date")
        day = parse_date(raw) if raw else timezone.localdate()
        if day is None:
            raise ValidationError({"date": "Use YYYY-MM-DD."})
        return Response(reports.daily_sales(day))


class StockAlertsView(APIView):
    """GET /api/reports/stock-alerts/ — ingredients at or below reorder level."""

    def get(self, request):
        return Response(IngredientSerializer(reports.stock_alerts(), many=True).data)
