"""Business logic: order processing, table availability, inventory auto-update.

Views stay thin; everything that must be atomic lives here.
"""
import logging
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from django.db import transaction
from django.utils import timezone
from rest_framework import status
from rest_framework.exceptions import APIException

from .models import (
    MAX_RESERVATION_MINUTES, Ingredient, Order, OrderItem, Reservation, Table,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------- exceptions
class RestaurantError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Invalid request."


class InsufficientStock(RestaurantError):
    status_code = status.HTTP_409_CONFLICT
    default_detail = "Not enough stock to fulfil this order."


class TableUnavailable(RestaurantError):
    status_code = status.HTTP_409_CONFLICT
    default_detail = "Table is not available for the requested time."


class InvalidTransition(RestaurantError):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Invalid order status change."


# ------------------------------------------------------------ order processing
ALLOWED_TRANSITIONS = {
    Order.Status.PENDING: {Order.Status.PREPARING, Order.Status.CANCELLED},
    Order.Status.PREPARING: {Order.Status.SERVED},
    Order.Status.SERVED: {Order.Status.PAID},
    Order.Status.PAID: set(),
    Order.Status.CANCELLED: set(),
}


def _ingredient_needs(lines):
    """lines: iterable of (MenuItem, qty) -> {ingredient_id: total Decimal needed}."""
    needs = defaultdict(Decimal)
    for item, qty in lines:
        for r in item.recipe.all():
            needs[r.ingredient_id] += r.quantity * qty
    return needs


@transaction.atomic
def place_order(*, table, customer_name, notes, lines):
    """Create an order and deduct ingredients from inventory — all or nothing.

    lines: list of (MenuItem, quantity). Raises InsufficientStock (409) if any
    ingredient would go negative; in that case nothing is saved or deducted.
    """
    if not lines:
        raise RestaurantError("An order needs at least one item.")
    if table is not None and not table.is_active:
        raise RestaurantError(f"Table {table.number} is out of service.")

    needs = _ingredient_needs(lines)

    # Lock rows (ordered by pk to avoid deadlocks between concurrent orders).
    stock = {
        ing.pk: ing
        for ing in Ingredient.objects.select_for_update().filter(pk__in=list(needs)).order_by("pk")
    }
    shortages = [
        f"{stock[i].name}: need {needed} {stock[i].unit}, only {stock[i].quantity} left"
        for i, needed in needs.items()
        if stock[i].quantity < needed
    ]
    if shortages:
        raise InsufficientStock(shortages)

    low = []
    for ing_id, needed in needs.items():
        ing = stock[ing_id]
        ing.quantity -= needed
        ing.save(update_fields=["quantity", "updated_at"])
        if ing.is_low:
            low.append(ing.name)
    if low:
        logger.warning("LOW STOCK after order: %s", ", ".join(low))

    order = Order.objects.create(table=table, customer_name=customer_name, notes=notes)
    OrderItem.objects.bulk_create(
        OrderItem(order=order, menu_item=item, quantity=qty, unit_price=item.price)
        for item, qty in lines
    )
    order.total = sum((item.price * qty for item, qty in lines), Decimal("0.00"))
    order.save(update_fields=["total", "updated_at"])
    return order


def _restock_order(order):
    needs = defaultdict(Decimal)
    for oi in order.items.select_related("menu_item").prefetch_related("menu_item__recipe"):
        for r in oi.menu_item.recipe.all():
            needs[r.ingredient_id] += r.quantity * oi.quantity
    for ing in Ingredient.objects.select_for_update().filter(pk__in=list(needs)).order_by("pk"):
        ing.quantity += needs[ing.pk]
        ing.save(update_fields=["quantity", "updated_at"])


@transaction.atomic
def change_order_status(order, new_status):
    """Move an order through PENDING -> PREPARING -> SERVED -> PAID.

    Cancelling (only allowed while PENDING) puts the ingredients back in stock.
    """
    order = Order.objects.select_for_update().get(pk=order.pk)
    if new_status not in ALLOWED_TRANSITIONS[order.status]:
        raise InvalidTransition(f"Cannot change order from {order.status} to {new_status}.")
    if new_status == Order.Status.CANCELLED:
        _restock_order(order)
    order.status = new_status
    order.save(update_fields=["status", "updated_at"])
    return order


# ---------------------------------------------------------- table availability
def table_is_free(table, start, end):
    """True if no confirmed reservation overlaps [start, end), and — when the
    window includes 'now' — the table has no active (unpaid) order."""
    candidates = Reservation.objects.filter(
        table=table,
        status=Reservation.Status.CONFIRMED,
        start_time__lt=end,
        start_time__gt=start - timedelta(minutes=MAX_RESERVATION_MINUTES),
    )
    if any(r.end_time > start for r in candidates):
        return False
    if start <= timezone.now() < end and table.orders.filter(status__in=Order.ACTIVE_STATUSES).exists():
        return False
    return True


def available_tables(start, duration_minutes=90, party_size=1):
    end = start + timedelta(minutes=duration_minutes)
    tables = Table.objects.filter(is_active=True, capacity__gte=party_size).order_by("capacity", "number")
    return [t for t in tables if table_is_free(t, start, end)]


@transaction.atomic
def create_reservation(*, table, customer_name, party_size, start_time, customer_phone="", duration_minutes=90):
    # Lock the table row so two simultaneous bookings can't both pass the check.
    table = Table.objects.select_for_update().get(pk=table.pk)
    if not table.is_active:
        raise RestaurantError(f"Table {table.number} is out of service.")
    if party_size > table.capacity:
        raise RestaurantError(f"Table {table.number} seats {table.capacity}, party is {party_size}.")
    end = start_time + timedelta(minutes=duration_minutes)
    if not table_is_free(table, start_time, end):
        raise TableUnavailable(f"Table {table.number} is already booked for that time slot.")
    return Reservation.objects.create(
        table=table, customer_name=customer_name, customer_phone=customer_phone,
        party_size=party_size, start_time=start_time, duration_minutes=duration_minutes,
    )


def cancel_reservation(reservation):
    if reservation.status != Reservation.Status.CONFIRMED:
        raise RestaurantError(f"Reservation is already {reservation.status}.")
    reservation.status = Reservation.Status.CANCELLED
    reservation.save(update_fields=["status"])
    return reservation


# ------------------------------------------------------------------- inventory
@transaction.atomic
def restock(ingredient, quantity):
    ingredient = Ingredient.objects.select_for_update().get(pk=ingredient.pk)
    ingredient.quantity += quantity
    ingredient.save(update_fields=["quantity", "updated_at"])
    return ingredient
