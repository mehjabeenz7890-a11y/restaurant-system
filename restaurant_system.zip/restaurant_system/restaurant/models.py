from datetime import timedelta
from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

MAX_RESERVATION_MINUTES = 360


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name_plural = "categories"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Ingredient(models.Model):
    """Inventory item (raw stock). Quantity is auto-updated by order processing."""

    class Unit(models.TextChoices):
        KG = "kg", "Kilogram"
        G = "g", "Gram"
        L = "l", "Litre"
        ML = "ml", "Millilitre"
        PCS = "pcs", "Pieces"

    name = models.CharField(max_length=120, unique=True)
    unit = models.CharField(max_length=5, choices=Unit.choices, default=Unit.KG)
    quantity = models.DecimalField(
        max_digits=12, decimal_places=3, default=Decimal("0"),
        validators=[MinValueValidator(Decimal("0"))],
    )
    reorder_level = models.DecimalField(
        max_digits=12, decimal_places=3, default=Decimal("0"),
        help_text="A stock alert is raised when quantity <= this level.",
    )
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    @property
    def is_low(self):
        return self.quantity <= self.reorder_level

    def __str__(self):
        return f"{self.name} ({self.quantity} {self.unit})"


class MenuItem(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="items")
    name = models.CharField(max_length=150, unique=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(
        max_digits=8, decimal_places=2, validators=[MinValueValidator(Decimal("0"))]
    )
    is_active = models.BooleanField(default=True, help_text="Untick to hide from the menu.")

    class Meta:
        ordering = ["category__name", "name"]

    @property
    def in_stock(self):
        """True if every ingredient in the recipe covers at least one serving."""
        return all(r.ingredient.quantity >= r.quantity for r in self.recipe.all())

    def __str__(self):
        return self.name


class RecipeItem(models.Model):
    """How much of an ingredient ONE serving of a menu item consumes."""

    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE, related_name="recipe")
    ingredient = models.ForeignKey(Ingredient, on_delete=models.PROTECT, related_name="used_in")
    quantity = models.DecimalField(
        max_digits=10, decimal_places=3, validators=[MinValueValidator(Decimal("0.001"))]
    )

    class Meta:
        unique_together = ("menu_item", "ingredient")

    def __str__(self):
        return f"{self.menu_item} needs {self.quantity} {self.ingredient.unit} {self.ingredient.name}"


class Table(models.Model):
    number = models.PositiveIntegerField(unique=True)
    capacity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    location = models.CharField(max_length=60, blank=True, help_text="e.g. Patio, Window")
    is_active = models.BooleanField(default=True, help_text="Untick if out of service.")

    class Meta:
        ordering = ["number"]

    def __str__(self):
        return f"Table {self.number} (seats {self.capacity})"


class Reservation(models.Model):
    class Status(models.TextChoices):
        CONFIRMED = "CONFIRMED", "Confirmed"
        CANCELLED = "CANCELLED", "Cancelled"
        COMPLETED = "COMPLETED", "Completed"

    table = models.ForeignKey(Table, on_delete=models.PROTECT, related_name="reservations")
    customer_name = models.CharField(max_length=120)
    customer_phone = models.CharField(max_length=20, blank=True)
    party_size = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    start_time = models.DateTimeField()
    duration_minutes = models.PositiveIntegerField(
        default=90,
        validators=[MinValueValidator(15), MaxValueValidator(MAX_RESERVATION_MINUTES)],
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.CONFIRMED)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["start_time"]
        indexes = [models.Index(fields=["table", "start_time"])]

    @property
    def end_time(self):
        return self.start_time + timedelta(minutes=self.duration_minutes)

    def __str__(self):
        return f"{self.customer_name} - {self.table} @ {self.start_time:%Y-%m-%d %H:%M}"


class Order(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        PREPARING = "PREPARING", "Preparing"
        SERVED = "SERVED", "Served"
        PAID = "PAID", "Paid"
        CANCELLED = "CANCELLED", "Cancelled"

    ACTIVE_STATUSES = (Status.PENDING, Status.PREPARING, Status.SERVED)

    table = models.ForeignKey(
        Table, null=True, blank=True, on_delete=models.SET_NULL, related_name="orders",
        help_text="Leave empty for takeaway.",
    )
    customer_name = models.CharField(max_length=120, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    notes = models.TextField(blank=True)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Order #{self.pk} [{self.status}]"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    menu_item = models.ForeignKey(MenuItem, on_delete=models.PROTECT, related_name="order_items")
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=8, decimal_places=2)  # price snapshot

    @property
    def line_total(self):
        return self.unit_price * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.menu_item}"
