from decimal import Decimal

from django.utils import timezone
from rest_framework import serializers

from . import services
from .models import (
    MAX_RESERVATION_MINUTES, Category, Ingredient, MenuItem, Order, OrderItem,
    RecipeItem, Reservation, Table,
)


# ------------------------------------------------------------------------ menu
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name"]


class MenuItemSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    in_stock = serializers.BooleanField(read_only=True)

    class Meta:
        model = MenuItem
        fields = ["id", "category", "category_name", "name", "description", "price", "is_active", "in_stock"]


class MenuCategorySerializer(serializers.ModelSerializer):
    items = MenuItemSerializer(many=True, read_only=True)

    class Meta:
        model = Category
        fields = ["id", "name", "items"]


class RecipeItemSerializer(serializers.ModelSerializer):
    ingredient_name = serializers.CharField(source="ingredient.name", read_only=True)

    class Meta:
        model = RecipeItem
        fields = ["id", "menu_item", "ingredient", "ingredient_name", "quantity"]


# ------------------------------------------------------------------- inventory
class IngredientSerializer(serializers.ModelSerializer):
    is_low = serializers.BooleanField(read_only=True)

    class Meta:
        model = Ingredient
        fields = ["id", "name", "unit", "quantity", "reorder_level", "is_low", "updated_at"]


class RestockSerializer(serializers.Serializer):
    quantity = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"))


# ----------------------------------------------------------------------- tables
class TableSerializer(serializers.ModelSerializer):
    class Meta:
        model = Table
        fields = ["id", "number", "capacity", "location", "is_active"]


class AvailabilityQuerySerializer(serializers.Serializer):
    start = serializers.DateTimeField()
    party_size = serializers.IntegerField(min_value=1, default=1)
    duration_minutes = serializers.IntegerField(min_value=15, max_value=MAX_RESERVATION_MINUTES, default=90)


class ReservationSerializer(serializers.ModelSerializer):
    end_time = serializers.DateTimeField(read_only=True)
    table_number = serializers.IntegerField(source="table.number", read_only=True)

    class Meta:
        model = Reservation
        fields = [
            "id", "table", "table_number", "customer_name", "customer_phone", "party_size",
            "start_time", "duration_minutes", "end_time", "status", "created_at",
        ]
        read_only_fields = ["status", "created_at"]

    def validate_start_time(self, value):
        if value <= timezone.now():
            raise serializers.ValidationError("Reservation must be in the future.")
        return value

    def create(self, validated_data):
        return services.create_reservation(**validated_data)


# ----------------------------------------------------------------------- orders
class OrderItemInputSerializer(serializers.Serializer):
    menu_item = serializers.PrimaryKeyRelatedField(
        queryset=MenuItem.objects.filter(is_active=True).prefetch_related("recipe")
    )
    quantity = serializers.IntegerField(min_value=1, max_value=100)


class OrderCreateSerializer(serializers.Serializer):
    table = serializers.PrimaryKeyRelatedField(queryset=Table.objects.all(), required=False, allow_null=True)
    customer_name = serializers.CharField(max_length=120, required=False, allow_blank=True, default="")
    notes = serializers.CharField(required=False, allow_blank=True, default="")
    items = OrderItemInputSerializer(many=True, allow_empty=False)

    def create(self, validated_data):
        lines = [(i["menu_item"], i["quantity"]) for i in validated_data["items"]]
        return services.place_order(
            table=validated_data.get("table"),
            customer_name=validated_data["customer_name"],
            notes=validated_data["notes"],
            lines=lines,
        )


class OrderItemSerializer(serializers.ModelSerializer):
    menu_item_name = serializers.CharField(source="menu_item.name", read_only=True)
    line_total = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)

    class Meta:
        model = OrderItem
        fields = ["id", "menu_item", "menu_item_name", "quantity", "unit_price", "line_total"]


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    table_number = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = [
            "id", "table", "table_number", "customer_name", "status", "notes",
            "total", "items", "created_at", "updated_at",
        ]

    def get_table_number(self, obj):
        return obj.table.number if obj.table_id else None


class OrderStatusSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Order.Status.choices)
