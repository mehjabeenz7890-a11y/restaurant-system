from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient

from .models import Category, Ingredient, MenuItem, Order, RecipeItem, Table


class BaseTest(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.staff = get_user_model().objects.create_user("chef", password="pw", is_staff=True)
        cat = Category.objects.create(name="Mains")
        self.cheese = Ingredient.objects.create(
            name="Cheese", unit="kg", quantity=Decimal("1.000"), reorder_level=Decimal("0.500"))
        self.dough = Ingredient.objects.create(
            name="Dough", unit="kg", quantity=Decimal("5.000"), reorder_level=Decimal("1.000"))
        self.pizza = MenuItem.objects.create(category=cat, name="Margherita", price=Decimal("250.00"))
        RecipeItem.objects.create(menu_item=self.pizza, ingredient=self.cheese, quantity=Decimal("0.200"))
        RecipeItem.objects.create(menu_item=self.pizza, ingredient=self.dough, quantity=Decimal("0.300"))
        self.table = Table.objects.create(number=1, capacity=4)

    def order(self, qty):
        return self.client.post(
            "/api/orders/",
            {"table": self.table.id, "items": [{"menu_item": self.pizza.id, "quantity": qty}]},
            format="json",
        )


class OrderTests(BaseTest):
    def test_menu_is_public(self):
        r = self.client.get("/api/menu/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()[0]["items"][0]["name"], "Margherita")
        self.assertTrue(r.json()[0]["items"][0]["in_stock"])

    def test_order_deducts_inventory_and_totals(self):
        r = self.order(2)
        self.assertEqual(r.status_code, 201)
        self.assertEqual(Decimal(r.json()["total"]), Decimal("500.00"))
        self.cheese.refresh_from_db()
        self.dough.refresh_from_db()
        self.assertEqual(self.cheese.quantity, Decimal("0.600"))
        self.assertEqual(self.dough.quantity, Decimal("4.400"))

    def test_insufficient_stock_rejects_and_changes_nothing(self):
        r = self.order(6)  # needs 1.2 kg cheese, only 1.0 available
        self.assertEqual(r.status_code, 409)
        self.assertEqual(Order.objects.count(), 0)
        self.cheese.refresh_from_db()
        self.dough.refresh_from_db()
        self.assertEqual(self.cheese.quantity, Decimal("1.000"))
        self.assertEqual(self.dough.quantity, Decimal("5.000"))

    def test_cancel_restocks(self):
        order_id = self.order(2).json()["id"]
        self.client.force_authenticate(self.staff)
        r = self.client.post(f"/api/orders/{order_id}/cancel/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["status"], "CANCELLED")
        self.cheese.refresh_from_db()
        self.assertEqual(self.cheese.quantity, Decimal("1.000"))

    def test_status_flow_and_invalid_transition(self):
        order_id = self.order(1).json()["id"]
        self.client.force_authenticate(self.staff)
        bad = self.client.post(f"/api/orders/{order_id}/status/", {"status": "SERVED"}, format="json")
        self.assertEqual(bad.status_code, 400)
        for st in ("PREPARING", "SERVED", "PAID"):
            ok = self.client.post(f"/api/orders/{order_id}/status/", {"status": st}, format="json")
            self.assertEqual(ok.status_code, 200)
        # a paid order can no longer be cancelled
        self.assertEqual(self.client.post(f"/api/orders/{order_id}/cancel/").status_code, 400)

    def test_staff_endpoints_require_login(self):
        self.assertIn(self.client.get("/api/orders/").status_code, (401, 403))
        self.assertIn(self.client.get("/api/inventory/").status_code, (401, 403))


class ReservationTests(BaseTest):
    def book(self, start, party=2, duration=90):
        return self.client.post(
            "/api/reservations/",
            {"table": self.table.id, "customer_name": "Asha", "party_size": party,
             "start_time": start.isoformat(), "duration_minutes": duration},
            format="json",
        )

    def test_overlap_is_rejected_but_back_to_back_is_allowed(self):
        start = timezone.now() + timedelta(days=1)
        self.assertEqual(self.book(start).status_code, 201)
        self.assertEqual(self.book(start + timedelta(minutes=30)).status_code, 409)
        self.assertEqual(self.book(start + timedelta(minutes=90)).status_code, 201)

    def test_party_larger_than_capacity_rejected(self):
        self.assertEqual(self.book(timezone.now() + timedelta(days=1), party=10).status_code, 400)

    def test_past_reservation_rejected(self):
        self.assertEqual(self.book(timezone.now() - timedelta(hours=1)).status_code, 400)

    def test_available_endpoint_excludes_booked_table(self):
        start = timezone.now() + timedelta(days=1)
        self.book(start)
        r = self.client.get("/api/tables/available/", {"start": start.isoformat(), "party_size": 2})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json(), [])
        later = start + timedelta(hours=3)
        r = self.client.get("/api/tables/available/", {"start": later.isoformat(), "party_size": 2})
        self.assertEqual([t["number"] for t in r.json()], [1])

    def test_cancelled_reservation_frees_table(self):
        start = timezone.now() + timedelta(days=1)
        rid = self.book(start).json()["id"]
        self.client.force_authenticate(self.staff)
        self.assertEqual(self.client.post(f"/api/reservations/{rid}/cancel/").status_code, 200)
        self.assertEqual(self.book(start).status_code, 201)


class InventoryAndReportTests(BaseTest):
    def test_restock_and_low_stock_alert(self):
        self.client.force_authenticate(self.staff)
        self.order(3)  # cheese 1.0 -> 0.4 (below reorder level 0.5)
        alerts = self.client.get("/api/reports/stock-alerts/").json()
        self.assertEqual([a["name"] for a in alerts], ["Cheese"])
        r = self.client.post(f"/api/inventory/{self.cheese.id}/restock/", {"quantity": "2"}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Decimal(r.json()["quantity"]), Decimal("2.400"))
        self.assertEqual(self.client.get("/api/reports/stock-alerts/").json(), [])

    def test_daily_sales_report(self):
        self.order(2)
        cancelled = self.order(1).json()["id"]
        self.client.force_authenticate(self.staff)
        self.client.post(f"/api/orders/{cancelled}/cancel/")
        r = self.client.get("/api/reports/daily-sales/").json()
        self.assertEqual(r["total_orders"], 1)
        self.assertEqual(r["cancelled_orders"], 1)
        self.assertEqual(Decimal(r["revenue"]), Decimal("500.00"))
        self.assertEqual(r["top_items"][0]["item"], "Margherita")
        self.assertEqual(r["top_items"][0]["units_sold"], 2)
