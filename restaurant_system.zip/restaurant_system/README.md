# Restaurant Management System (Django + Django REST Framework)

Backend for restaurant operations: menu, orders, tables, reservations and inventory,
with automatic stock deduction, table-availability checks, reports and a Django admin panel.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations restaurant
python manage.py migrate
python manage.py seed_data      # demo menu, stock, tables + dev superuser admin / admin123
python manage.py runserver
python manage.py test           # run the test-suite
```

* Admin panel: http://127.0.0.1:8000/admin/
* Browsable API: http://127.0.0.1:8000/api/

## Project layout

```
config/               settings, root urls
restaurant/
  models.py           Category, MenuItem, Ingredient, RecipeItem, Table, Reservation, Order, OrderItem
  services.py         business logic (order processing, availability, inventory) – all atomic
  reports.py          daily sales + stock alerts
  serializers.py / views.py / urls.py   REST API
  admin.py            admin panel (stock-aware order actions)
  tests.py            API/business-logic tests
  management/commands/seed_data.py
```

## Database design

| Model | Purpose / key fields |
|---|---|
| Category, MenuItem | `name, price, is_active`, belongs to a category |
| Ingredient | inventory: `quantity, unit, reorder_level` |
| RecipeItem | links MenuItem → Ingredient with the quantity used per serving |
| Table | `number, capacity, location, is_active` |
| Reservation | `table, customer, party_size, start_time, duration_minutes, status` |
| Order / OrderItem | `table (optional = takeaway), status, total`; items keep a **price snapshot** |

## Business logic (restaurant/services.py)

* **Order processing** – `place_order` runs in one DB transaction: it totals the ingredients
  needed for *all* lines, locks the inventory rows, rejects the order with **409** if anything is short
  (nothing is changed), otherwise deducts stock, creates the order and computes the total.
* **Inventory auto-update** – stock is deducted on order placement and restored if a
  `PENDING` order is cancelled. Items without a recipe don't consume stock. A log warning is
  written when an ingredient falls to/below its reorder level.
* **Order lifecycle** – `PENDING → PREPARING → SERVED → PAID`; cancel only from `PENDING`.
* **Table availability** – a table is free for `[start, start+duration)` when no confirmed
  reservation overlaps it (back-to-back bookings are fine) and, if the slot includes "now",
  it has no active order. Reservations also check capacity ≥ party size, and the table row is locked
  to prevent double-booking by concurrent requests.

## API

Public = no login. Staff = user with `is_staff` (token, session or basic auth).

| Method & URL | Access | Description |
|---|---|---|
| GET `/api/menu/` | public | Menu grouped by category, with `in_stock` flag |
| GET/POST/PUT/DELETE `/api/menu-items/`, `/api/categories/` | read public, write staff | Manage menu |
| `/api/recipe-items/` | staff | Define ingredient usage per dish |
| POST `/api/orders/` | public | Place an order |
| GET `/api/orders/?status=PENDING`, `/api/orders/{id}/` | staff | List / view orders |
| POST `/api/orders/{id}/status/` `{"status": "PREPARING"}` | staff | Advance order |
| POST `/api/orders/{id}/cancel/` | staff | Cancel + restock |
| GET `/api/tables/available/?start=...&party_size=4&duration_minutes=90` | public | Free tables for a slot |
| `/api/tables/` | staff | Manage tables |
| POST `/api/reservations/` | public | Reserve a table |
| GET `/api/reservations/?date=YYYY-MM-DD`, POST `/api/reservations/{id}/cancel/` | staff | View / cancel |
| `/api/inventory/` (CRUD) | staff | Manage stock |
| POST `/api/inventory/{id}/restock/` `{"quantity": 5}` | staff | Add stock |
| GET `/api/inventory/low-stock/`, GET `/api/reports/stock-alerts/` | staff | Items at/below reorder level |
| GET `/api/reports/daily-sales/?date=YYYY-MM-DD` | staff | Orders, revenue, avg order, top 5 items |
| POST `/api/auth/token/` | public | Get an API token (`username`, `password`) |

## Example session

```bash
# 1. get a staff token
curl -X POST localhost:8000/api/auth/token/ -d "username=admin&password=admin123"

# 2. view the menu
curl localhost:8000/api/menu/

# 3. place an order (dine-in at table 3)
curl -X POST localhost:8000/api/orders/ -H "Content-Type: application/json" \
  -d '{"table": 3, "customer_name": "Ravi", "items": [{"menu_item": 1, "quantity": 2}, {"menu_item": 4, "quantity": 1}]}'

# 4. check free tables, then reserve (use Z / URL-encode '+' in timestamps)
curl "localhost:8000/api/tables/available/?start=2026-10-20T19:00:00Z&party_size=4"
curl -X POST localhost:8000/api/reservations/ -H "Content-Type: application/json" \
  -d '{"table": 3, "customer_name": "Asha", "party_size": 4, "start_time": "2026-10-20T19:00:00Z"}'

# 5. staff: advance the order, restock, reports
TOKEN=<token from step 1>
curl -X POST localhost:8000/api/orders/1/status/ -H "Authorization: Token $TOKEN" -H "Content-Type: application/json" -d '{"status":"PREPARING"}'
curl -X POST localhost:8000/api/inventory/2/restock/ -H "Authorization: Token $TOKEN" -H "Content-Type: application/json" -d '{"quantity": 5}'
curl localhost:8000/api/reports/daily-sales/ -H "Authorization: Token $TOKEN"
curl localhost:8000/api/reports/stock-alerts/ -H "Authorization: Token $TOKEN"
```

## Admin panel

`/admin/` lets staff manage menu, recipes, stock (with a "Low stock?" indicator), tables,
reservations and orders. Order status/items are read-only in admin; use the bulk actions
(Mark PREPARING/SERVED/PAID, Cancel & restock) so inventory stays consistent.

## Notes / possible extensions

* SQLite by default; switch `DATABASES` for PostgreSQL in production (row locking is then fully effective).
* Set `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0`, `DJANGO_ALLOWED_HOSTS` and change the seeded admin password before deploying.
* Cancelling restocks using the *current* recipe; if you edit a recipe while orders are open, adjust stock manually.
